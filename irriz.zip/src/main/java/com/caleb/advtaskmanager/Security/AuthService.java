package com.caleb.advtaskmanager.Security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.caleb.advtaskmanager.Entities.User;
import com.caleb.advtaskmanager.Repositories.UserRepository;

import lombok.RequiredArgsConstructor;
import tools.jackson.databind.json.JsonMapper;

@Service
@RequiredArgsConstructor
public class AuthService {
    private static final JsonMapper JSON = JsonMapper.builder().build();
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Value("${auth.jwt.secret:change-this-secret-in-production}")
    private String secret;

    @Value("${auth.jwt.expiration-ms:86400000}")
    private long expirationMs;

    @Value("${auth.enabled:true}")
    private boolean enabled;

    public String authenticate(String username, String password) {
        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid username or password"));
        if (user.getPasswordHash() == null || !passwordEncoder.matches(password, user.getPasswordHash())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid username or password");
        }
        return tokenFor(user);
    }

    public String tokenFor(User user) {
        long expiresAt = Instant.now().toEpochMilli() + expirationMs;
        String header = encode("{\"alg\":\"HS256\",\"typ\":\"JWT\"}");
        String payload = encode(write(Map.of("sub", user.getId().toString(), "exp", expiresAt)));
        return header + "." + payload + "." + sign(header + "." + payload);
    }

    public Long userIdFromToken(String token) {
        try {
            String[] parts = token.split("\\.", -1);
            if (parts.length != 3 || !MessageDigest.isEqual(sign(parts[0] + "." + parts[1])
                    .getBytes(StandardCharsets.US_ASCII), parts[2].getBytes(StandardCharsets.US_ASCII))) return null;
            Map<?, ?> payload = JSON.readValue(new String(Base64.getUrlDecoder().decode(parts[1]), StandardCharsets.UTF_8), Map.class);
            long expiration = ((Number) payload.get("exp")).longValue();
            if (expiration < Instant.now().toEpochMilli()) return null;
            return Long.valueOf(payload.get("sub").toString());
        } catch (RuntimeException exception) {
            return null;
        }
    }

    public void requireCurrentUser(Long userId) {
        if (!enabled) return;
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof Long currentId)
                || !currentId.equals(userId)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You are not allowed to access this resource");
        }
    }

    public Long currentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.getPrincipal() instanceof Long id ? id : null;
    }

    public Long scopedUserId(Long requestedUserId) {
        Long currentId = currentUserId();
        if (!enabled) return requestedUserId;
        if (currentId == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Authentication is required");
        }
        if (requestedUserId != null && !currentId.equals(requestedUserId)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You are not allowed to access this resource");
        }
        return currentId;
    }

    public boolean isEnabled() {
        return enabled;
    }

    private String encode(String value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private String write(Map<String, ?> value) {
        return JSON.writeValueAsString(value);
    }

    private String sign(String value) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to sign authentication token", exception);
        }
    }
}
